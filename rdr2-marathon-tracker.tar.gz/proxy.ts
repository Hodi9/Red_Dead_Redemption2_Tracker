import { COOKIE_NAME, createSessionToken, isAuthConfigured, isValidSession } from "@/lib/auth"
import { NextRequest, NextResponse } from "next/server"

export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl

  if (!isAuthConfigured()) {
    return new NextResponse(renderConfigurationError(), {
      status: 503,
      headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" },
    })
  }

  if (await isValidSession(request.cookies.get(COOKIE_NAME)?.value)) return NextResponse.next()
  if (request.method === "POST") return handleLoginAttempt(request, pathname)
  return loginResponse(pathname)
}

async function handleLoginAttempt(request: NextRequest, pathname: string) {
  const formData = await request.formData()
  const submitted = formData.get("password")
  const password = process.env.CONTROL_PANEL_PASSWORD

  if (typeof submitted === "string" && password && submitted === password) {
    const response = NextResponse.redirect(new URL(pathname, request.url), 303)
    response.cookies.set(COOKIE_NAME, await createSessionToken(), {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 60 * 60 * 24 * 7,
      path: "/",
    })
    return response
  }

  return loginResponse(pathname, true)
}

function loginResponse(pathname: string, wrongPassword = false) {
  return new NextResponse(renderLoginPage(pathname, wrongPassword), {
    status: 401,
    headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" },
  })
}

function renderLoginPage(pathname: string, wrongPassword = false) {
  const safePath = pathname.replaceAll("&", "&amp;").replaceAll('"', "&quot;").replaceAll("<", "&lt;")
  return `<!DOCTYPE html><html lang="da"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Adgang krævet</title><style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0a0a0a;font-family:system-ui,sans-serif}.card{width:100%;max-width:340px;padding:32px;border-radius:12px;background:#171717;border:1px solid #262626}h1{color:#fff;font-size:18px;margin:0 0 4px}p{color:#a3a3a3;font-size:13px;margin:0 0 20px}input{width:100%;box-sizing:border-box;padding:10px 12px;border-radius:8px;border:1px solid #333;background:#0a0a0a;color:#fff;font-size:14px;margin-bottom:12px}button{width:100%;padding:10px 12px;border-radius:8px;border:0;background:#dc2626;color:#fff;font-weight:600;font-size:14px;cursor:pointer}.error{color:#f87171;font-size:13px;margin-bottom:12px}</style></head><body><div class="card"><h1>Control panel</h1><p>Denne side kræver adgangskode.</p><form method="POST" action="${safePath}">${wrongPassword ? '<div class="error">Forkert adgangskode. Prøv igen.</div>' : ""}<input type="password" name="password" placeholder="Adgangskode" autocomplete="current-password" required autofocus><button type="submit">Log ind</button></form></div></body></html>`
}

function renderConfigurationError() {
  return `<!DOCTYPE html><html lang="da"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mangler opsætning</title></head><body style="margin:40px;background:#0a0a0a;color:#fff;font-family:system-ui"><h1>Kontrolpanelet er ikke konfigureret</h1><p>Tilføj CONTROL_PANEL_PASSWORD og AUTH_SECRET som miljøvariabler.</p></body></html>`
}

export const config = { matcher: "/control/:path*" }
