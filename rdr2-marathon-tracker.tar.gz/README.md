# RDR2 Marathon Tracker

Et live overlay til OBS/Streamlabs med et adgangskodebeskyttet kontrolpanel. Fremdriften gemmes i PostgreSQL og deles mellem overlayet og kontrolpanelet.

## Lokal kørsel

1. Installér pakker med `pnpm install`.
2. Kopiér `.env.example` til `.env.local` og udfyld værdierne.
3. Start med `pnpm dev`.
4. Åbn `/overlay` til OBS og `/control` til betjening.

Databasetabellen oprettes automatisk ved første kald. Brug en PostgreSQL-database, eksempelvis Neon eller Vercel Postgres.

## Deployment på Render + Pogly Cloud

1. Opret en Render Blueprint fra repository'ets `render.yaml`.
2. Indtast `CONTROL_PANEL_PASSWORD`, når Render beder om den. Databaseadresse og sessionshemmelighed oprettes automatisk.
3. Åbn den tildelte `onrender.com/control`-adresse og test betjeningen.
4. Tilføj `https://DIN-RENDER-ADRESSE/overlay` som Website Embed i Pogly Cloud.
5. Brug derefter kun Poglys normale overlayadresse som Browser Source i OBS.

Den skjulte side `/bridge` kan indlejres i et native Pogly-widget og sender
progressionen til widgetens parent-frame. Pogly-editorer kan dermed flytte,
skalere og skjule widgetelementet live uden at påvirke den automatiske tracker.

## Automatisk PC-tracking

`tracker`-mappen indeholder en skrivebeskyttet Windows-tracker. Den overvåger
den nyeste RDR2-save og sender missionsnavnet til `/api/tracker`. På Render skal
`TRACKER_API_KEY` være sat, og den samme hemmelighed skal stå i den lokale
`tracker-config.json`, som aldrig må committes.

Adgangskoden må ikke skrives i kildekoden eller committes i en `.env`-fil. Overlayets læse-API er offentligt med vilje, mens alle ændringer kræver en signeret login-session.
