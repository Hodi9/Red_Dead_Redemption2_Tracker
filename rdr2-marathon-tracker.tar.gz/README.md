# red-dead-redemption2-tracker

This is a [Next.js](https://nextjs.org) project bootstrapped with [v0](https://v0.app).

## Built with v0

This repository is linked to a [v0](https://v0.app) project. You can continue developing by visiting the link below -- start new chats to make changes, and v0 will push commits directly to this repo. Every merge to `main` will automatically deploy.

[Continue working on v0 →](https://v0.app/chat/projects/prj_IZV2GxvDUDVYOnGNAncfcEKBALUn)

## Automatic RDR2 PC tracking

The `tracker` folder contains a read-only Windows companion that watches the
newest `SRDR3*` save. It reads only the human-readable UTF-16 save header, maps
the last completed mission through the server, and updates the existing shared
`missionIndex`. It never writes to a game save.

1. Add `TRACKER_API_KEY` to the deployed app's environment variables. Use a
   long random secret and redeploy.
2. Copy `tracker/tracker-config.example.json` to
   `tracker/tracker-config.json` and enter the deployed URL and the same secret.
3. Double-click `tracker/Start RDR2 Tracker.cmd` on the gaming PC.

The control panel and OBS overlay already poll `/api/state`, so they reflect a
successful save sync within about 1.5 seconds. Manual controls remain available
as a fallback.

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

## Learn More

To learn more, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.
- [v0 Documentation](https://v0.app/docs) - learn about v0 and how to use it.
