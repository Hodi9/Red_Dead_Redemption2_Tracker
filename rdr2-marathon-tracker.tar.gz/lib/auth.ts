const COOKIE_NAME = "control_auth"
const SESSION_VALUE = "rdr2-control-panel-v1"

export { COOKIE_NAME }

function getAuthSecret(): string | null {
  return process.env.AUTH_SECRET?.trim() || null
}

export function isAuthConfigured(): boolean {
  return Boolean(process.env.CONTROL_PANEL_PASSWORD?.trim() && getAuthSecret())
}

function toHex(bytes: ArrayBuffer): string {
  return Array.from(new Uint8Array(bytes), (byte) => byte.toString(16).padStart(2, "0")).join("")
}

async function sessionSignature(): Promise<string | null> {
  const secret = getAuthSecret()
  if (!secret) return null
  const encoder = new TextEncoder()
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"])
  return toHex(await crypto.subtle.sign("HMAC", key, encoder.encode(SESSION_VALUE)))
}

export async function createSessionToken(): Promise<string> {
  const signature = await sessionSignature()
  if (!signature) throw new Error("AUTH_SECRET is not configured")
  return signature
}

export async function isValidSession(token: string | undefined): Promise<boolean> {
  if (!token) return false
  const expected = await sessionSignature()
  if (!expected || token.length !== expected.length) return false
  let difference = 0
  for (let index = 0; index < token.length; index += 1) difference |= token.charCodeAt(index) ^ expected.charCodeAt(index)
  return difference === 0
}
