"use client"

import type { MarathonProgress } from "@/lib/missions"
import useSWR from "swr"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

/**
 * Polls the shared marathon state. Both the overlay and the control panel use
 * this so they stay in sync across browsers, refreshes, and OBS restarts.
 */
export function useProgress(refreshInterval = 1500) {
  const { data, error, isLoading, mutate } = useSWR<MarathonProgress>("/api/state", fetcher, {
    refreshInterval,
    revalidateOnFocus: true,
    keepPreviousData: true,
  })

  return { progress: data, error, isLoading, mutate }
}
