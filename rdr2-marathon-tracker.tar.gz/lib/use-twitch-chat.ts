"use client"

import { useCallback, useEffect, useRef, useState } from "react"

export type ChatCommand = {
  /** The command keyword without the leading "!", lowercased. e.g. "next". */
  command: string
  /** Everything after the command, trimmed. e.g. "42" or "chapter 3". */
  args: string
  /** Display name of the sender. */
  user: string
  /** Whether the sender is a mod or the broadcaster. */
  isPrivileged: boolean
}

export type ConnectionStatus = "idle" | "connecting" | "connected" | "error"

type Options = {
  channel: string
  enabled: boolean
  onCommand: (cmd: ChatCommand) => void
}

/**
 * Anonymous, read-only connection to a Twitch channel's chat via tmi.js.
 * No auth/token needed — we only listen. Mod/broadcaster status is read from
 * the IRC message tags so only privileged users can drive the overlay.
 */
export function useTwitchChat({ channel, enabled, onCommand }: Options) {
  const [status, setStatus] = useState<ConnectionStatus>("idle")
  const [error, setError] = useState<string | null>(null)
  const clientRef = useRef<any>(null)
  // Keep the latest callback without forcing a reconnect on every render.
  const onCommandRef = useRef(onCommand)
  onCommandRef.current = onCommand

  useEffect(() => {
    const name = channel.trim().toLowerCase().replace(/^#/, "")
    if (!enabled || !name) {
      setStatus("idle")
      return
    }

    let cancelled = false
    let client: any = null

    setStatus("connecting")
    setError(null)

    // tmi.js is browser-only; import it lazily so it never runs during SSR.
    import("tmi.js")
      .then(({ Client }) => {
        if (cancelled) return
        client = new Client({
          options: { skipUpdatingEmotesets: true },
          connection: { reconnect: true, secure: true },
          channels: [name],
        })
        clientRef.current = client

        client.on("connected", () => {
          if (!cancelled) setStatus("connected")
        })
        client.on("disconnected", () => {
          if (!cancelled) setStatus("idle")
        })

        client.on("message", (_channel: string, tags: any, message: string, self: boolean) => {
          if (self) return
          const text = message.trim()
          if (!text.startsWith("!")) return

          const [rawCommand, ...rest] = text.slice(1).split(/\s+/)
          const badges = tags?.badges ?? {}
          const isPrivileged =
            tags?.mod === true ||
            tags?.badges?.broadcaster === "1" ||
            badges?.broadcaster === "1" ||
            tags?.["user-type"] === "mod" ||
            tags?.username?.toLowerCase() === name

          onCommandRef.current({
            command: rawCommand.toLowerCase(),
            args: rest.join(" ").trim(),
            user: tags?.["display-name"] ?? tags?.username ?? "unknown",
            isPrivileged: Boolean(isPrivileged),
          })
        })

        return client.connect()
      })
      .catch((err) => {
        if (cancelled) return
        console.log("[v0] Twitch connect error:", err)
        setStatus("error")
        setError(err?.message ?? "Failed to connect to Twitch chat")
      })

    return () => {
      cancelled = true
      const c = clientRef.current
      clientRef.current = null
      if (c) {
        try {
          c.removeAllListeners?.()
          c.disconnect?.()
        } catch {
          // ignore teardown errors
        }
      }
    }
  }, [channel, enabled])

  const reconnect = useCallback(() => {
    const c = clientRef.current
    if (c) {
      try {
        c.disconnect?.()
      } catch {
        // ignore
      }
    }
  }, [])

  return { status, error, reconnect }
}
