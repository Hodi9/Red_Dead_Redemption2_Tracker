// The single source of truth for the marathon.
// The overlay percentage, mission count, and current chapter are all derived
// from this ordered list. Edit names/order/entries here to fit your run —
// the total ("X / N MISSIONS") is simply this array's length.

export type Mission = {
  /** Mission name as shown in-game. */
  name: string
  /** Story act, e.g. "Chapter 1" or "Epilogue 2". */
  chapter: string
  /** Camp / region location for that act, e.g. "Colter". */
  location: string
}

export const MISSIONS: Mission[] = [
  // Chapter 1: Colter
  { name: "Outlaws from the West", chapter: "Chapter 1", location: "Colter" },
  { name: "Enter, Pursued by a Memory", chapter: "Chapter 1", location: "Colter" },
  { name: "Old Friends", chapter: "Chapter 1", location: "Colter" },
  { name: "The Aftermath of Genesis", chapter: "Chapter 1", location: "Colter" },
  { name: "Who the Hell is Leviticus Cornwall?", chapter: "Chapter 1", location: "Colter" },
  { name: "Eastward Bound", chapter: "Chapter 1", location: "Colter" },

  // Chapter 2: Horseshoe Overlook
  { name: "Polite Society, Valentine Style", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "Americans at Rest", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "The First Shall Be Last", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "Exit Pursued by a Bruised Ego", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "Who Is Not Without Sin", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "Money Lending and Other Sins I", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "Money Lending and Other Sins II", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "Money Lending and Other Sins III", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "Paying a Social Call", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "A Quiet Time", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "Blessed Are the Meek?", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "We Loved Once and True I", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "We Loved Once and True II", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "We Loved Once and True III", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "The Spines of America", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "Pouring Forth Oil I", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "Pouring Forth Oil II", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "Pouring Forth Oil III", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "Pouring Forth Oil IV", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "A Fisher of Men", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "The Sheep and the Goats", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "An American Pastoral Scene", chapter: "Chapter 2", location: "Horseshoe Overlook" },
  { name: "A Strange Kindness", chapter: "Chapter 2", location: "Horseshoe Overlook" },

  // Chapter 3: Clemens Point
  { name: "Further Questions of Female Suffrage", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "The New South", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "The Course of True Love I", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "The Course of True Love II", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "The Course of True Love III", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "American Distillation", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "Advertising, the New American Art", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "An Honest Mistake", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "Horse Flesh for Dinner", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "The Fine Joys of Tobacco", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "Preaching Forgiveness as He Went", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "Magicians for Sport", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "Sodom? Back to Gomorrah", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "Blessed Are the Peacemakers", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "Friends in Very Low Places", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "A Short Walk in a Pretty Town", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "Blood Feuds, Ancient and Modern", chapter: "Chapter 3", location: "Clemens Point" },
  { name: "The Battle of Shady Belle", chapter: "Chapter 3", location: "Clemens Point" },

  // Chapter 4: Saint Denis
  { name: "The Joys of Civilization", chapter: "Chapter 4", location: "Saint Denis" },
  { name: "Angelo Bronte, a Man of Honor", chapter: "Chapter 4", location: "Saint Denis" },
  { name: "No, No and Thrice, No", chapter: "Chapter 4", location: "Saint Denis" },
  { name: "Fatherhood and Other Dreams I", chapter: "Chapter 4", location: "Saint Denis" },
  { name: "Fatherhood and Other Dreams II", chapter: "Chapter 4", location: "Saint Denis" },
  { name: "The Gilded Cage", chapter: "Chapter 4", location: "Saint Denis" },
  { name: "A Fine Night of Debauchery", chapter: "Chapter 4", location: "Saint Denis" },
  { name: "Horsemen, Apocalypses", chapter: "Chapter 4", location: "Saint Denis" },
  { name: "Urban Pleasures", chapter: "Chapter 4", location: "Saint Denis" },
  { name: "Country Pursuits", chapter: "Chapter 4", location: "Saint Denis" },
  { name: "Revenge Is a Dish Best Eaten", chapter: "Chapter 4", location: "Saint Denis" },
  { name: "Banking, the Old American Art", chapter: "Chapter 4", location: "Saint Denis" },

  // Chapter 5: Guarma
  { name: "Welcome to the New World", chapter: "Chapter 5", location: "Guarma" },
  { name: "Savagery Unleashed", chapter: "Chapter 5", location: "Guarma" },
  { name: "Hell Hath No Fury", chapter: "Chapter 5", location: "Guarma" },
  { name: "A Kind and Benevolent Despot", chapter: "Chapter 5", location: "Guarma" },
  { name: "Paradise Mercifully Departed", chapter: "Chapter 5", location: "Guarma" },
  { name: "Dear Uncle Tacitus", chapter: "Chapter 5", location: "Guarma" },

  // Chapter 6: Beaver Hollow
  { name: "Icarus and Friends", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Of Men and Angels", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Do Not Seek Absolution I", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Do Not Seek Absolution II", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Visiting Hours", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "The Course of True Love IV", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "The Course of True Love V", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Just a Social Call", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "A Rage Unleashed", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "The Delights of Van Horn", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "The Bridge to Nowhere", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Archeology for Beginners", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Honor, Amongst Thieves", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Money Lending and Other Sins VI", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Money Lending and Other Sins VII", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Goodbye, Dear Friend", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "The Fine Art of Conversation", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Favored Sons", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Mrs. Sadie Adler, Widow I", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Mrs. Sadie Adler, Widow II", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "The King's Son", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "My Last Boy", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Our Best Selves", chapter: "Chapter 6", location: "Beaver Hollow" },
  { name: "Red Dead Redemption", chapter: "Chapter 6", location: "Beaver Hollow" },

  // Epilogue 1: Pronghorn Ranch
  { name: "The Wheel", chapter: "Epilogue 1", location: "Pronghorn Ranch" },
  { name: "Simple Pleasures", chapter: "Epilogue 1", location: "Pronghorn Ranch" },
  { name: "Fatherhood for Beginners", chapter: "Epilogue 1", location: "Pronghorn Ranch" },
  { name: "Farming for Beginners", chapter: "Epilogue 1", location: "Pronghorn Ranch" },
  { name: "Old Habits", chapter: "Epilogue 1", location: "Pronghorn Ranch" },
  { name: "Jim Milton Rides, Again?", chapter: "Epilogue 1", location: "Pronghorn Ranch" },
  { name: "Fatherhood for Idiots", chapter: "Epilogue 1", location: "Pronghorn Ranch" },
  { name: "Motherhood", chapter: "Epilogue 1", location: "Pronghorn Ranch" },
  { name: "Gainful Employment", chapter: "Epilogue 1", location: "Pronghorn Ranch" },
  { name: "Home of the Gentry?", chapter: "Epilogue 1", location: "Pronghorn Ranch" },

  // Epilogue 2: Beecher's Hope
  { name: "Bare Knuckle Friendships", chapter: "Epilogue 2", location: "Beecher's Hope" },
  { name: "Home Improvement for Beginners", chapter: "Epilogue 2", location: "Beecher's Hope" },
  { name: "An Honest Day's Labors", chapter: "Epilogue 2", location: "Beecher's Hope" },
  { name: "The Tool Box", chapter: "Epilogue 2", location: "Beecher's Hope" },
  { name: "A New Jerusalem", chapter: "Epilogue 2", location: "Beecher's Hope" },
  { name: "A Quick Favor for an Old Friend", chapter: "Epilogue 2", location: "Beecher's Hope" },
  { name: "Uncle's Bad Day", chapter: "Epilogue 2", location: "Beecher's Hope" },
  { name: "Trying Again", chapter: "Epilogue 2", location: "Beecher's Hope" },
  { name: "A Really Big Bastard", chapter: "Epilogue 2", location: "Beecher's Hope" },
  { name: "A New Future Imagined", chapter: "Epilogue 2", location: "Beecher's Hope" },
  { name: "American Venom", chapter: "Epilogue 2", location: "Beecher's Hope" },
]

export const TOTAL_MISSIONS = MISSIONS.length

/** Normalize the title stored in RDR2's save header for reliable matching. */
export function normalizeMissionName(value: string): string {
  return value
    .normalize("NFKD")
    .replace(/[’‘]/g, "'")
    .replace(/[–—-]/g, " ")
    .replace(/[^a-zA-Z0-9' ]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase()
}

/** Returns the zero-based story mission index represented by a save title. */
export function findMissionIndexFromSaveTitle(saveTitle: string): number {
  const wanted = normalizeMissionName(saveTitle.replace(/^\(Autosave\)\s*/i, ""))
  return MISSIONS.findIndex((mission) => normalizeMissionName(mission.name) === wanted)
}

export type MarathonProgress = {
  missionIndex: number
  total: number
  completed: number
  percent: number
  isComplete: boolean
  currentMission: Mission | null
  chapter: string
  location: string
}

/**
 * Derives everything the UI needs from a raw missionIndex.
 * missionIndex = number of missions completed = index of the mission in progress.
 */
export function deriveProgress(missionIndex: number): MarathonProgress {
  const total = TOTAL_MISSIONS
  const completed = Math.max(0, Math.min(missionIndex, total))
  const isComplete = completed >= total
  const currentMission = isComplete ? null : MISSIONS[completed]
  const percent = total === 0 ? 0 : (completed / total) * 100

  return {
    missionIndex: completed,
    total,
    completed,
    percent,
    isComplete,
    currentMission,
    chapter: isComplete ? "Story Complete" : currentMission!.chapter,
    location: isComplete ? "" : currentMission!.location,
  }
}
