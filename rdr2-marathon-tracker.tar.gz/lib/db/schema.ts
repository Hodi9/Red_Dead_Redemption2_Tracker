import { integer, pgTable, text, timestamp } from "drizzle-orm/pg-core"

// Single shared marathon state for the overlay + control panel.
// The row keyed "default" is the one both pages read/write.
export const marathonState = pgTable("marathon_state", {
  id: text("id").primaryKey().default("default"),
  // Number of missions the streamer has completed (also the index of the
  // mission currently in progress). 0 = not started, missions.length = finished.
  missionIndex: integer("mission_index").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
})
