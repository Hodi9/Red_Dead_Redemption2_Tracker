import { drizzle } from "drizzle-orm/node-postgres"
import { Pool } from "pg"
import * as schema from "./schema"

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
})

export const db = drizzle(pool, { schema })

let setupPromise: Promise<unknown> | undefined

export function ensureDatabase() {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is not configured")
  setupPromise ??= pool.query(`
    CREATE TABLE IF NOT EXISTS marathon_state (
      id text PRIMARY KEY DEFAULT 'default',
      mission_index integer NOT NULL DEFAULT 0,
      game_percent double precision,
      updated_at timestamptz NOT NULL DEFAULT now()
    );
    ALTER TABLE marathon_state
      ADD COLUMN IF NOT EXISTS game_percent double precision;
  `)
  return setupPromise
}
