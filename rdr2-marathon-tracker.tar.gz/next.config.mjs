/** @type {import('next').NextConfig} */
const nextConfig = {
  async headers() {
    return [
      {
        source: '/overlay',
        headers: [
          {
            key: 'Content-Security-Policy',
            value: "frame-ancestors 'self' https://cloud.pogly.gg https://*.pogly.gg",
          },
        ],
      },
    ]
  },
  images: {
    unoptimized: true,
  },
}

export default nextConfig
