"use client"

import {
  advance,
  jumpToChapter,
  resetProgress,
  retreat,
  setMissionNumber,
} from "@/app/actions/marathon"
import { Button } from "@/components/ui/button"
import { MISSIONS } from "@/lib/missions"
import { useProgress } from "@/lib/use-progress"
import { type ChatCommand, useTwitchChat } from "@/lib/use-twitch-chat"
import { useCallback, useEffect, useMemo, useRef, useState } from "react"

type LogEntry = { id: number; text: string; kind: "ok" | "info" | "warn" }

export function ControlPanel() {
  const { progress, mutate } = useProgress(1500)
  const [channelInput, setChannelInput] = useState("")
  const [channel, setChannel] = useState("")
  const [listening, setListening] = useState(false)
  const [log, setLog] = useState<LogEntry[]>([])
  const logId = useRef(0)
  const activeRef = useRef<HTMLButtonElement | null>(null)

  // Restore the saved channel (operator config lives locally on this device).
  useEffect(() => {
    const saved = localStorage.getItem("rdr2-marathon-channel")
    if (saved) {
      setChannelInput(saved)
      setChannel(saved)
      setListening(true)
    }
  }, [])

  const pushLog = useCallback((text: string, kind: LogEntry["kind"] = "info") => {
    setLog((prev) => [{ id: logId.current++, text, kind }, ...prev].slice(0, 30))
  }, [])

  const applyAndRefresh = useCallback(
    async (fn: () => Promise<unknown>) => {
      await fn()
      mutate()
    },
    [mutate],
  )

  const handleCommand = useCallback(
    (cmd: ChatCommand) => {
      const known = ["next", "advance", "prev", "back", "mission", "chapter", "reset"]
      if (!known.includes(cmd.command)) return

      if (!cmd.isPrivileged) {
        pushLog(`Ignored !${cmd.command} from ${cmd.user} (not a mod)`, "warn")
        return
      }

      switch (cmd.command) {
        case "next":
        case "advance":
          applyAndRefresh(advance)
          pushLog(`${cmd.user}: !${cmd.command} → advanced`, "ok")
          break
        case "prev":
        case "back":
          applyAndRefresh(retreat)
          pushLog(`${cmd.user}: !${cmd.command} → went back`, "ok")
          break
        case "mission": {
          const n = Number.parseInt(cmd.args, 10)
          if (Number.isFinite(n) && n >= 1 && n <= MISSIONS.length) {
            applyAndRefresh(() => setMissionNumber(n))
            pushLog(`${cmd.user}: !mission ${n}`, "ok")
          } else {
            pushLog(`${cmd.user}: !mission "${cmd.args}" invalid`, "warn")
          }
          break
        }
        case "chapter":
          if (cmd.args) {
            applyAndRefresh(() => jumpToChapter(cmd.args))
            pushLog(`${cmd.user}: !chapter ${cmd.args}`, "ok")
          }
          break
        case "reset":
          applyAndRefresh(resetProgress)
          pushLog(`${cmd.user}: !reset`, "ok")
          break
      }
    },
    [applyAndRefresh, pushLog],
  )

  const { status, error } = useTwitchChat({
    channel,
    enabled: listening,
    onCommand: handleCommand,
  })

  const completed = progress?.completed ?? 0
  const total = progress?.total ?? MISSIONS.length
  const percent = progress?.percent ?? 0

  // Auto-scroll the mission list to the current mission when it changes.
  useEffect(() => {
    activeRef.current?.scrollIntoView({ block: "center", behavior: "smooth" })
  }, [completed])

  const grouped = useMemo(() => {
    const groups: { chapter: string; location: string; items: { index: number }[] }[] = []
    MISSIONS.forEach((m, index) => {
      const last = groups[groups.length - 1]
      if (last && last.chapter === m.chapter) {
        last.items.push({ index })
      } else {
        groups.push({ chapter: m.chapter, location: m.location, items: [{ index }] })
      }
    })
    return groups
  }, [])

  function connect() {
    const name = channelInput.trim().toLowerCase().replace(/^#/, "")
    if (!name) return
    localStorage.setItem("rdr2-marathon-channel", name)
    setChannel(name)
    setListening(true)
    pushLog(`Listening to #${name}`, "info")
  }

  function disconnect() {
    setListening(false)
    localStorage.removeItem("rdr2-marathon-channel")
    pushLog("Stopped listening", "info")
  }

  const statusMeta: Record<string, { label: string; className: string }> = {
    idle: { label: "Offline", className: "bg-muted-foreground" },
    connecting: { label: "Connecting…", className: "bg-yellow-500 animate-pulse" },
    connected: { label: "Live", className: "bg-green-500" },
    error: { label: "Error", className: "bg-destructive" },
  }
  const sm = statusMeta[status] ?? statusMeta.idle

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-8">
      <header className="mb-8 flex flex-col gap-1">
        <h1 className="font-display text-4xl font-bold uppercase tracking-tight text-foreground">
          Marathon Control
        </h1>
        <p className="text-sm text-muted-foreground">
          Red Dead Redemption 2 · story progress operator panel
        </p>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1fr_1.1fr]">
        {/* Left column: status + controls + twitch */}
        <div className="flex flex-col gap-6">
          {/* Current status */}
          <section className="rounded-lg border border-border bg-card p-6">
            <div className="flex items-baseline justify-between gap-4">
              <span className="text-xs font-medium uppercase tracking-widest text-muted-foreground">
                Current progress
              </span>
              <span className="font-display text-3xl font-bold tabular-nums text-foreground">
                {percent.toFixed(1)}%
              </span>
            </div>

            <div className="mt-3 h-3 w-full overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full bg-primary transition-[width] duration-500"
                style={{ width: `${percent}%` }}
              />
            </div>

            <div className="mt-4 font-display text-2xl font-semibold uppercase tabular-nums text-foreground">
              {completed} / {total} Missions
            </div>
            <div className="mt-1 text-sm font-medium uppercase tracking-wide text-muted-foreground">
              {progress?.isComplete
                ? "Story Complete"
                : `${progress?.chapter ?? ""} · ${progress?.location ?? ""}`}
            </div>
            {progress?.currentMission ? (
              <div className="mt-2 text-base font-medium text-primary">
                {progress.currentMission.name}
              </div>
            ) : null}

            <div className="mt-5 flex flex-wrap gap-2">
              <Button variant="secondary" onClick={() => applyAndRefresh(retreat)}>
                ← Back
              </Button>
              <Button onClick={() => applyAndRefresh(advance)}>Advance →</Button>
              <Button
                variant="outline"
                className="ml-auto"
                onClick={() => {
                  if (confirm("Reset the marathon back to 0%?")) applyAndRefresh(resetProgress)
                }}
              >
                Reset
              </Button>
            </div>
          </section>

          {/* Twitch chat */}
          <section className="rounded-lg border border-border bg-card p-6">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold uppercase tracking-wide text-foreground">
                Twitch chat
              </h2>
              <span className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                <span className={`h-2.5 w-2.5 rounded-full ${sm.className}`} aria-hidden />
                {sm.label}
              </span>
            </div>

            <div className="flex gap-2">
              <input
                value={channelInput}
                onChange={(e) => setChannelInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.nativeEvent.isComposing && e.keyCode !== 229) connect()
                }}
                placeholder="twitch channel name"
                className="min-w-0 flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:ring-2 focus:ring-ring"
              />
              {listening ? (
                <Button variant="secondary" onClick={disconnect}>
                  Stop
                </Button>
              ) : (
                <Button onClick={connect}>Listen</Button>
              )}
            </div>

            {error ? <p className="mt-2 text-xs text-destructive">{error}</p> : null}

            <div className="mt-4 rounded-md border border-border bg-background/50 p-3">
              <p className="mb-2 text-xs font-medium uppercase tracking-widest text-muted-foreground">
                Mod commands
              </p>
              <ul className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-muted-foreground">
                <li>
                  <code className="text-foreground">!next</code> advance
                </li>
                <li>
                  <code className="text-foreground">!back</code> previous
                </li>
                <li>
                  <code className="text-foreground">!mission 42</code> jump
                </li>
                <li>
                  <code className="text-foreground">!chapter 3</code> jump
                </li>
                <li>
                  <code className="text-foreground">!reset</code> to 0%
                </li>
              </ul>
            </div>

            {/* Command log */}
            <div className="mt-4 max-h-40 overflow-y-auto">
              {log.length === 0 ? (
                <p className="text-xs text-muted-foreground">No commands yet.</p>
              ) : (
                <ul className="flex flex-col gap-1">
                  {log.map((e) => (
                    <li
                      key={e.id}
                      className={`text-xs ${
                        e.kind === "ok"
                          ? "text-green-500"
                          : e.kind === "warn"
                            ? "text-yellow-500"
                            : "text-muted-foreground"
                      }`}
                    >
                      {e.text}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </section>
        </div>

        {/* Right column: mission list */}
        <section className="rounded-lg border border-border bg-card p-4">
          <div className="mb-3 flex items-center justify-between px-2">
            <h2 className="font-display text-lg font-semibold uppercase tracking-wide text-foreground">
              Missions
            </h2>
            <span className="text-xs text-muted-foreground">Click a mission to set current</span>
          </div>
          <div className="max-h-[70vh] overflow-y-auto pr-1">
            {grouped.map((group) => (
              <div key={group.chapter} className="mb-4">
                <div className="sticky top-0 z-10 bg-card/95 px-2 py-1.5 backdrop-blur">
                  <span className="text-xs font-bold uppercase tracking-widest text-primary">
                    {group.chapter}
                  </span>
                  <span className="ml-2 text-xs uppercase tracking-wide text-muted-foreground">
                    {group.location}
                  </span>
                </div>
                <ul className="mt-1">
                  {group.items.map(({ index }) => {
                    const isCurrent = index === completed
                    const isDone = index < completed
                    return (
                      <li key={index}>
                        <button
                          ref={isCurrent ? activeRef : undefined}
                          onClick={() => applyAndRefresh(() => setMissionNumber(index + 1))}
                          className={`flex w-full items-center gap-3 rounded-md px-2 py-1.5 text-left text-sm transition-colors ${
                            isCurrent
                              ? "bg-primary/15 text-foreground ring-1 ring-primary/50"
                              : "hover:bg-secondary"
                          }`}
                        >
                          <span
                            className={`w-6 flex-none text-right text-xs tabular-nums ${
                              isDone ? "text-muted-foreground" : "text-muted-foreground/60"
                            }`}
                          >
                            {index + 1}
                          </span>
                          <span
                            className={`flex-none ${
                              isDone
                                ? "text-green-500"
                                : isCurrent
                                  ? "text-primary"
                                  : "text-muted-foreground/40"
                            }`}
                            aria-hidden
                          >
                            {isDone ? "✓" : isCurrent ? "▶" : "○"}
                          </span>
                          <span
                            className={`truncate ${
                              isDone ? "text-muted-foreground line-through" : "text-foreground"
                            }`}
                          >
                            {MISSIONS[index].name}
                          </span>
                        </button>
                      </li>
                    )
                  })}
                </ul>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
