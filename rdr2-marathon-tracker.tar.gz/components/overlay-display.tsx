"use client"

import { useProgress } from "@/lib/use-progress"
import { useEffect } from "react"

export function OverlayDisplay() {
  const { progress } = useProgress(1500)

  // OBS Browser Sources render on a transparent canvas. Force the document
  // background transparent so only the text/bar show over the game capture.
  useEffect(() => {
    const html = document.documentElement
    const body = document.body
    const prevHtml = html.style.background
    const prevBody = body.style.background
    html.style.background = "transparent"
    body.style.background = "transparent"
    return () => {
      html.style.background = prevHtml
      body.style.background = prevBody
    }
  }, [])

  const hasGamePercent = progress?.gamePercent != null
  const percent = progress?.gamePercent ?? progress?.percent ?? 0
  const completed = progress?.completed ?? 0
  const total = progress?.total ?? 0
  const isComplete = progress?.isComplete ?? false
  const chapter = progress?.chapter ?? "Chapter 1"
  const location = progress?.location ?? "Colter"
  const missionName = progress?.currentMission?.name ?? ""

  return (
    <div className="tracker-overlay min-h-screen w-full bg-transparent p-10 font-display">
      <div className="tracker-overlay-copy inline-block max-w-2xl select-none">
        {/* Big percentage */}
        <div className="text-6xl font-bold uppercase leading-none tracking-tight text-white tabular-nums">
          {percent.toFixed(1)}%
        </div>
        <div className="mt-1 text-sm font-semibold uppercase tracking-[0.16em] text-white/75">
          {hasGamePercent ? "Total Completion" : "Tracked Mission Progress"}
        </div>

        {/* Thin outlined progress bar */}
        <div className="tracker-progress-rail mt-3 h-4 w-[36rem] max-w-full rounded-[3px] border-2 border-white p-[3px]">
          <div
            className="h-full rounded-[1px] border-r-2 border-white bg-white/20 transition-[width] duration-700 ease-out"
            style={{ width: `${Math.max(0, Math.min(100, percent))}%` }}
          />
        </div>

        {/* Mission count */}
        <div className="mt-3 text-4xl font-bold uppercase leading-none tracking-tight text-white tabular-nums">
          {completed} / {total} Tracked Missions
        </div>

        {/* Current chapter + location */}
        <div className="mt-1 text-xl font-semibold uppercase tracking-[0.12em] text-white/85">
          {isComplete ? "Story Complete" : `${chapter} \u00B7 ${location}`}
        </div>

        {/* Current mission name */}
        {!isComplete && missionName ? (
          <div className="mt-2 flex items-center gap-2 text-lg font-medium uppercase tracking-[0.08em] text-[var(--color-primary)]">
            <span
              aria-hidden
              className="inline-block h-2 w-2 flex-none rotate-45 bg-[var(--color-primary)]"
            />
            <span className="[text-shadow:0_2px_8px_rgba(0,0,0,0.9)]">{missionName}</span>
          </div>
        ) : null}
      </div>
    </div>
  )
}
