import { OverlayDisplay } from "@/components/overlay-display"

// The page OBS/Streamlabs loads as a Browser Source.
export default function OverlayPage() {
  return (
    <>
      {/* Render this with the initial HTML so embeds never paint the dark app background. */}
      <style>{`
        html, body {
          background: transparent !important;
          background-color: transparent !important;
          color-scheme: normal !important;
        }
      `}</style>
      <OverlayDisplay />
    </>
  )
}
