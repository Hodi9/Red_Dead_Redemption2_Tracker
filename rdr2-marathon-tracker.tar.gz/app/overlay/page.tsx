import { OverlayDisplay } from "@/components/overlay-display"

// The page OBS/Streamlabs loads as a Browser Source.
export default function OverlayPage() {
  return <OverlayDisplay />
}
