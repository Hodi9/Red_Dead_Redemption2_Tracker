import { setProgressFromTracker } from "@/app/actions/marathon"
import { findMissionIndexFromSaveTitle } from "@/lib/missions"
import { NextRequest, NextResponse } from "next/server"

export const dynamic = "force-dynamic"

function isAuthorized(request: NextRequest): boolean {
  const expected = process.env.TRACKER_API_KEY
  return Boolean(expected) && request.headers.get("authorization") === `Bearer ${expected}`
}

export async function POST(request: NextRequest) {
  if (!isAuthorized(request)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const body = (await request.json()) as { saveTitle?: unknown; gamePercent?: unknown }
    if (typeof body.saveTitle !== "string" || body.saveTitle.length > 160) {
      return NextResponse.json({ error: "saveTitle must be a string" }, { status: 400 })
    }
    if (
      typeof body.gamePercent !== "number" ||
      !Number.isFinite(body.gamePercent) ||
      body.gamePercent < 0 ||
      body.gamePercent > 100
    ) {
      return NextResponse.json({ error: "gamePercent must be a number from 0 to 100" }, { status: 400 })
    }

    const matchedIndex = findMissionIndexFromSaveTitle(body.saveTitle)
    if (matchedIndex < 0) {
      return NextResponse.json({
        ok: true,
        matched: false,
        saveTitle: body.saveTitle,
        gamePercent: body.gamePercent,
        progress: await setProgressFromTracker(body.gamePercent, null),
      })
    }

    const progress = await setProgressFromTracker(body.gamePercent, matchedIndex + 1)
    return NextResponse.json({
      ok: true,
      matched: true,
      saveTitle: body.saveTitle,
      gamePercent: body.gamePercent,
      progress,
    })
  } catch (error) {
    console.error("/api/tracker error", error)
    return NextResponse.json({ error: "Failed to update tracker" }, { status: 500 })
  }
}
