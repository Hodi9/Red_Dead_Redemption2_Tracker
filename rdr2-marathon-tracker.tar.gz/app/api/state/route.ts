import { getProgress } from "@/app/actions/marathon"
import { NextResponse } from "next/server"

// Always read fresh from the database so the overlay reflects the latest state.
export const dynamic = "force-dynamic"
export const revalidate = 0

export async function GET() {
  try {
    const progress = await getProgress()
    return NextResponse.json(progress, {
      headers: { "Cache-Control": "no-store, max-age=0" },
    })
  } catch (error) {
    console.log("[v0] /api/state error:", error)
    return NextResponse.json({ error: "Failed to read marathon state" }, { status: 500 })
  }
}
