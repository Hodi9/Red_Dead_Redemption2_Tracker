import { getProgress } from "@/app/actions/marathon"
import { NextResponse } from "next/server"

const apiHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Cache-Control": "no-store, max-age=0",
}

// Always read fresh from the database so the overlay reflects the latest state.
export const dynamic = "force-dynamic"
export const revalidate = 0

export async function GET() {
  try {
    const progress = await getProgress()
    return NextResponse.json(progress, {
      headers: apiHeaders,
    })
  } catch (error) {
    console.log("[v0] /api/state error:", error)
    return NextResponse.json(
      { error: "Failed to read marathon state" },
      { status: 500, headers: apiHeaders },
    )
  }
}

export function OPTIONS() {
  return new NextResponse(null, {
    status: 204,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  })
}
