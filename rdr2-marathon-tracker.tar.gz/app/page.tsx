import { buttonVariants } from "@/components/ui/button"
import { TOTAL_MISSIONS } from "@/lib/missions"
import Link from "next/link"

export default function HomePage() {
  return (
    <main className="min-h-screen bg-background">
      <div className="mx-auto max-w-4xl px-6 py-16">
        <header className="mb-12">
          <p className="mb-2 text-xs font-medium uppercase tracking-[0.2em] text-primary">
            Twitch stream overlay
          </p>
          <h1 className="font-display text-5xl font-bold uppercase leading-none tracking-tight text-foreground text-balance">
            Red Dead Redemption 2 Marathon Tracker
          </h1>
          <p className="mt-4 max-w-2xl text-muted-foreground leading-relaxed">
            A live story-progress overlay for your RDR2 marathon. Progress is tracked across all{" "}
            {TOTAL_MISSIONS} story missions and saved to a database, so it survives browser
            refreshes and OBS restarts. Drive it from the control panel or let your mods run it from
            Twitch chat.
          </p>
        </header>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="flex flex-col rounded-lg border border-border bg-card p-6">
            <h2 className="font-display text-xl font-semibold uppercase tracking-wide text-foreground">
              Overlay
            </h2>
            <p className="mt-2 flex-1 text-sm text-muted-foreground leading-relaxed">
              The transparent page you add to OBS as a Browser Source. Shows the percentage,
              mission count, current chapter, and current mission.
            </p>
            <div className="mt-4 flex gap-2">
              <Link className={buttonVariants()} href="/overlay" target="_blank">
                Open overlay
              </Link>
            </div>
          </div>

          <div className="flex flex-col rounded-lg border border-border bg-card p-6">
            <h2 className="font-display text-xl font-semibold uppercase tracking-wide text-foreground">
              Control panel
            </h2>
            <p className="mt-2 flex-1 text-sm text-muted-foreground leading-relaxed">
              Your operator page. Click the current mission, use Back / Advance, and connect to
              Twitch chat so mods can drive progress with commands.
            </p>
            <div className="mt-4 flex gap-2">
              <Link className={buttonVariants()} href="/control">
                Open control panel
              </Link>
            </div>
          </div>
        </div>

        <section className="mt-10 rounded-lg border border-border bg-card p-6">
          <h2 className="font-display text-xl font-semibold uppercase tracking-wide text-foreground">
            OBS / Streamlabs setup
          </h2>
          <ol className="mt-4 flex flex-col gap-3 text-sm text-muted-foreground leading-relaxed">
            <li>
              <span className="font-semibold text-foreground">1.</span> In OBS, add a{" "}
              <span className="text-foreground">Browser</span> source to your scene.
            </li>
            <li>
              <span className="font-semibold text-foreground">2.</span> Set the URL to this
              app&apos;s{" "}
              <code className="rounded bg-secondary px-1.5 py-0.5 text-foreground">/overlay</code>{" "}
              page, width <span className="text-foreground">1920</span> and height{" "}
              <span className="text-foreground">1080</span>.
            </li>
            <li>
              <span className="font-semibold text-foreground">3.</span> The background is transparent
              automatically — position the text wherever you like over your gameplay.
            </li>
            <li>
              <span className="font-semibold text-foreground">4.</span> Keep{" "}
              <code className="rounded bg-secondary px-1.5 py-0.5 text-foreground">/control</code>{" "}
              open on a second monitor or phone, and connect it to your Twitch channel.
            </li>
          </ol>
        </section>
      </div>
    </main>
  )
}
