"use client"

import { useEffect } from "react"
import { useProgress } from "@/lib/use-progress"

export default function TrackerBridgePage() {
  const { progress } = useProgress(1500)

  useEffect(() => {
    if (!progress || window.parent === window) return

    window.parent.postMessage(
      {
        source: "rdr2-marathon-tracker",
        type: "progress",
        progress,
      },
      "*",
    )
  }, [progress])

  return null
}
