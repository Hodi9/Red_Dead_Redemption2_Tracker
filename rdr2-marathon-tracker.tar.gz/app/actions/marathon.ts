"use server"

import { db } from "@/lib/db"
import { marathonState } from "@/lib/db/schema"
import { deriveProgress, MISSIONS, TOTAL_MISSIONS, type MarathonProgress } from "@/lib/missions"
import { eq } from "drizzle-orm"

const ROW_ID = "default"

async function readIndex(): Promise<number> {
  const rows = await db
    .select()
    .from(marathonState)
    .where(eq(marathonState.id, ROW_ID))
    .limit(1)

  if (rows.length === 0) {
    // Self-heal: recreate the singleton row if it is ever missing.
    await db.insert(marathonState).values({ id: ROW_ID, missionIndex: 0 }).onConflictDoNothing()
    return 0
  }
  return rows[0].missionIndex
}

async function writeIndex(index: number): Promise<number> {
  const clamped = Math.max(0, Math.min(Math.trunc(index), TOTAL_MISSIONS))
  await db
    .insert(marathonState)
    .values({ id: ROW_ID, missionIndex: clamped, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: marathonState.id,
      set: { missionIndex: clamped, updatedAt: new Date() },
    })
  return clamped
}

/** Read the current progress (used by the polling API route). */
export async function getProgress(): Promise<MarathonProgress> {
  const index = await readIndex()
  return deriveProgress(index)
}

/** Set the mission currently in progress by 1-based mission number. */
export async function setMissionNumber(missionNumber: number): Promise<MarathonProgress> {
  const index = await writeIndex(missionNumber - 1)
  return deriveProgress(index)
}

/** Set the raw completed-mission count directly. */
export async function setMissionIndex(index: number): Promise<MarathonProgress> {
  const next = await writeIndex(index)
  return deriveProgress(next)
}

/** Advance to the next mission (mark current complete). */
export async function advance(): Promise<MarathonProgress> {
  const index = await readIndex()
  return deriveProgress(await writeIndex(index + 1))
}

/** Go back one mission. */
export async function retreat(): Promise<MarathonProgress> {
  const index = await readIndex()
  return deriveProgress(await writeIndex(index - 1))
}

/** Jump to the first mission of a named chapter (e.g. "Chapter 3", "Epilogue 1"). */
export async function jumpToChapter(chapterQuery: string): Promise<MarathonProgress> {
  const q = chapterQuery.trim().toLowerCase()
  const target = MISSIONS.findIndex(
    (m) => m.chapter.toLowerCase() === q || m.location.toLowerCase() === q,
  )
  if (target === -1) {
    // No match — return current state unchanged.
    return getProgress()
  }
  return deriveProgress(await writeIndex(target))
}

/** Reset the marathon back to the start. */
export async function resetProgress(): Promise<MarathonProgress> {
  return deriveProgress(await writeIndex(0))
}
