"use server"

import { db, ensureDatabase } from "@/lib/db"
import { COOKIE_NAME, isValidSession } from "@/lib/auth"
import { marathonState } from "@/lib/db/schema"
import { deriveProgress, MISSIONS, TOTAL_MISSIONS, type MarathonProgress } from "@/lib/missions"
import { eq } from "drizzle-orm"
import { cookies } from "next/headers"

const ROW_ID = "default"

async function requireControlAccess() {
  const cookieStore = await cookies()
  if (!(await isValidSession(cookieStore.get(COOKIE_NAME)?.value))) throw new Error("Unauthorized")
}

async function readState(): Promise<{ missionIndex: number; gamePercent: number | null }> {
  await ensureDatabase()
  const rows = await db
    .select()
    .from(marathonState)
    .where(eq(marathonState.id, ROW_ID))
    .limit(1)

  if (rows.length === 0) {
    // Self-heal: recreate the singleton row if it is ever missing.
    await db.insert(marathonState).values({ id: ROW_ID, missionIndex: 0 }).onConflictDoNothing()
    return { missionIndex: 0, gamePercent: null }
  }
  return { missionIndex: rows[0].missionIndex, gamePercent: rows[0].gamePercent }
}

async function writeIndex(index: number): Promise<number> {
  await ensureDatabase()
  const clamped = Math.max(0, Math.min(Math.trunc(index), TOTAL_MISSIONS))
  await db
    .insert(marathonState)
    .values({ id: ROW_ID, missionIndex: clamped, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: marathonState.id,
      set: { missionIndex: clamped, updatedAt: new Date() },
    })
  return clamped
}

/** Read the current progress (used by the polling API route). */
export async function getProgress(): Promise<MarathonProgress> {
  const state = await readState()
  return deriveProgress(state.missionIndex, state.gamePercent)
}

/** Set the mission currently in progress by 1-based mission number. */
export async function setMissionNumber(missionNumber: number): Promise<MarathonProgress> {
  await requireControlAccess()
  const index = await writeIndex(missionNumber - 1)
  return deriveProgress(index)
}

/** Set the raw completed-mission count directly. */
export async function setMissionIndex(index: number): Promise<MarathonProgress> {
  await requireControlAccess()
  const next = await writeIndex(index)
  return deriveProgress(next)
}

/** Store Total Completion and, for story saves, the matched mission position. */
export async function setProgressFromTracker(
  gamePercent: number,
  matchedMissionIndex: number | null,
): Promise<MarathonProgress> {
  await ensureDatabase()
  const current = await readState()
  // Autosave slots rotate, so the most-recently-written save file can briefly be an
  // older one (e.g. a stale slot getting touched). Never let a matched mission regress
  // the tracked count — only gamePercent (read straight from the save) can move freely.
  const index =
    matchedMissionIndex == null ? current.missionIndex : Math.max(current.missionIndex, matchedMissionIndex)
  const clampedIndex = Math.max(0, Math.min(Math.trunc(index), TOTAL_MISSIONS))
  const clampedPercent = Math.max(0, Math.min(gamePercent, 100))
  await db
    .insert(marathonState)
    .values({
      id: ROW_ID,
      missionIndex: clampedIndex,
      gamePercent: clampedPercent,
      updatedAt: new Date(),
    })
    .onConflictDoUpdate({
      target: marathonState.id,
      set: {
        missionIndex: clampedIndex,
        gamePercent: clampedPercent,
        updatedAt: new Date(),
      },
    })
  return deriveProgress(clampedIndex, clampedPercent)
}

/** Advance to the next mission (mark current complete). */
export async function advance(): Promise<MarathonProgress> {
  await requireControlAccess()
  const state = await readState()
  return deriveProgress(await writeIndex(state.missionIndex + 1), state.gamePercent)
}

/** Go back one mission. */
export async function retreat(): Promise<MarathonProgress> {
  await requireControlAccess()
  const state = await readState()
  return deriveProgress(await writeIndex(state.missionIndex - 1), state.gamePercent)
}

/** Jump to the first mission of a named chapter (e.g. "Chapter 3", "Epilogue 1"). */
export async function jumpToChapter(chapterQuery: string): Promise<MarathonProgress> {
  await requireControlAccess()
  const q = chapterQuery.trim().toLowerCase()
  const target = MISSIONS.findIndex(
    (m) => m.chapter.toLowerCase() === q || m.location.toLowerCase() === q,
  )
  if (target === -1) {
    // No match — return current state unchanged.
    return getProgress()
  }
  return deriveProgress(await writeIndex(target))
}

/** Reset the marathon back to the start. */
export async function resetProgress(): Promise<MarathonProgress> {
  await requireControlAccess()
  await ensureDatabase()
  // writeIndex only touches missionIndex; a full reset must also clear the
  // last-known gamePercent, or the overlay keeps showing the old save's
  // Total Completion % (it prefers gamePercent over the derived percent).
  await db
    .insert(marathonState)
    .values({ id: ROW_ID, missionIndex: 0, gamePercent: null, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: marathonState.id,
      set: { missionIndex: 0, gamePercent: null, updatedAt: new Date() },
    })
  return deriveProgress(0, null)
}
