import { ControlPanel } from "@/components/control-panel"

export default function ControlPage() {
  return (
    <main className="min-h-screen bg-background">
      <ControlPanel />
    </main>
  )
}
