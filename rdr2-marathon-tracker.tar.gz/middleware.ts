import { NextRequest, NextResponse } from "next/server"

// Sæt dit password her, ELLER som environment variable CONTROL_PANEL_PASSWORD
// i Vercel (Project Settings -> Environment Variables). Env variable er sikrere,
// da den ikke ligger i koden / på GitHub.
const PASSWORD = process.env.CONTROL_PANEL_PASSWORD || "u-+FRPtCMt@Rew02x4ZF"

const COOKIE_NAME = "control_auth"

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Beskyt kun /control (og undersider, hvis der er nogen)
  if (!pathname.startsWith("/control")) {
    return NextResponse.next()
  }

  // Har brugeren allerede en gyldig auth-cookie?
  const authCookie = request.cookies.get(COOKIE_NAME)?.value
  if (authCookie === PASSWORD) {
    return NextResponse.next()
  }

  // Prøver brugeren at logge ind lige nu? (POST fra login-formularen)
  if (request.method === "POST") {
    return handleLoginAttempt(request, pathname)
  }

  // Ellers: vis login-siden
  return new NextResponse(renderLoginPage(pathname), {
    status: 401,
    headers: { "Content-Type": "text/html; charset=utf-8" },
  })
}

async function handleLoginAttempt(request: NextRequest, pathname: string) {
  const formData = await request.formData()
  const submitted = formData.get("password")

  if (submitted === PASSWORD) {
    const response = NextResponse.redirect(new URL(pathname, request.url))
    response.cookies.set(COOKIE_NAME, PASSWORD, {
      httpOnly: true,
      secure: true,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 30, // 30 dage
      path: "/",
    })
    return response
  }

  return new NextResponse(renderLoginPage(pathname, true), {
    status: 401,
    headers: { "Content-Type": "text/html; charset=utf-8" },
  })
}

function renderLoginPage(pathname: string, wrongPassword = false) {
  return `<!DOCTYPE html>
<html lang="da">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Adgang krævet</title>
  <style>
    body {
      margin: 0;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #0a0a0a;
      font-family: system-ui, -apple-system, sans-serif;
    }
    .card {
      width: 100%;
      max-width: 340px;
      padding: 32px;
      border-radius: 12px;
      background: #171717;
      border: 1px solid #262626;
    }
    h1 {
      color: #fff;
      font-size: 18px;
      margin: 0 0 4px;
    }
    p {
      color: #a3a3a3;
      font-size: 13px;
      margin: 0 0 20px;
    }
    input {
      width: 100%;
      box-sizing: border-box;
      padding: 10px 12px;
      border-radius: 8px;
      border: 1px solid #333;
      background: #0a0a0a;
      color: #fff;
      font-size: 14px;
      margin-bottom: 12px;
    }
    button {
      width: 100%;
      padding: 10px 12px;
      border-radius: 8px;
      border: none;
      background: #dc2626;
      color: #fff;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
    }
    button:hover { background: #b91c1c; }
    .error {
      color: #f87171;
      font-size: 13px;
      margin-bottom: 12px;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>Control panel</h1>
    <p>Denne side kræver adgangskode.</p>
    <form method="POST" action="${pathname}">
      ${wrongPassword ? '<div class="error">Forkert password, prøv igen.</div>' : ""}
      <input type="password" name="password" placeholder="Password" autofocus />
      <button type="submit">Log ind</button>
    </form>
  </div>
</body>
</html>`
}

export const config = {
  matcher: "/control/:path*",
}
